1. Run Main File named as "TechGig_WonderlustRobo.xaml".

2.For running this Workflow you have to send email to robot for asking services.

3. Email Subject should be "Service Type <Name Of Service>" .

Example :- Service Type food

4.For Workflow running pass arguments carefully

5. Video is available in "Video Folder".

6. Presentation is available in "Presentation Folder".